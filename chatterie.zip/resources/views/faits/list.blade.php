@props([
'faits'
])

<x-layout :titre="'Liste des faits félins | Chatterie'">

    <!-- Affichage de la liste des films -->
    <!-- Utilisation du composant fait-card -->

    <section class="py-12 bg-gray-900">
        <h1 class="text-5xl text-gray-100 font-bold mb-8 text-center">Liste des citations</h1>
        <div class="flex flex-wrap justify-center">
            @foreach($faits as $fait)
            <x-faits.fait-card
                :id="$fait->id"
                :fait="$fait->court_fait"
                :editUrl="route('faits.edit', ['id' => $fait->id])"
                :deleteUrl="route('faits.destroy', ['id' => $fait->id])" />
            @endforeach
        </div>
    </section>

</x-layout>

<!-- PALETTE
    Rouge   #C72B3B
    Crème   #f6f2ef
    Générateur de pattern   https://www.cssportal.com/css-pattern-generator/
-->