<x-layout :titre="'Modifier le fait sur les félins | Chatterie'">

<!-- {{ dd($fait) }} -->

<!-- <h1 class="text-4xl font-bold text-center text-gray-900 mb-8">Modifier un Fait</h1>
    
    <section class="py-12 bg-gray-900">
        <h1 class="text-5xl text-gray-100 font-bold mb-8 text-center">Ajoutez une citation</h1>
        <div class="flex flex-wrap justify-center">
            {{ dd($fait) }}
        </div>
    </section> -->

<h1 class="text-4xl font-bold text-center text-gray-900 mb-8">Modifier un Fait</h1>
    
    <section class="py-12 bg-gray-900">
        <h1 class="text-5xl text-gray-100 font-bold mb-8 text-center">Ajoutez une citation</h1>
        <div class="flex flex-wrap justify-center">
            <!-- Utilisation du composant fait-form -->
                <!-- <x-faits.fait-edit-form :fait="$fait" />-->
        </div>
    </section>
    
</x-layout>