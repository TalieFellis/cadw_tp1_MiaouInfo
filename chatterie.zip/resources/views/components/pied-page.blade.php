<footer class="text-gray-500 py-4 my-8 bg-gray-200">
    <p class="container mx-auto text-center">
        Chatterie &copy; {{ now()->year }} Tous droits réservés.
    </p>
</footer>