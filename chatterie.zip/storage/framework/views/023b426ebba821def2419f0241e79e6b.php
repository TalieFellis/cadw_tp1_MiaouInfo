<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['titre' => 'Modifier le fait sur les félins | Chatterie']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Modifier le fait sur les félins | Chatterie')]); ?>

<!-- <?php echo e(dd($fait)); ?> -->

<!-- <h1 class="text-4xl font-bold text-center text-gray-900 mb-8">Modifier un Fait</h1>
    
    <section class="py-12 bg-gray-900">
        <h1 class="text-5xl text-gray-100 font-bold mb-8 text-center">Ajoutez une citation</h1>
        <div class="flex flex-wrap justify-center">
            <?php echo e(dd($fait)); ?>

        </div>
    </section> -->

<h1 class="text-4xl font-bold text-center text-gray-900 mb-8">Modifier un Fait</h1>
    
    <section class="py-12 bg-gray-900">
        <h1 class="text-5xl text-gray-100 font-bold mb-8 text-center">Ajoutez une citation</h1>
        <div class="flex flex-wrap justify-center">
            <!-- Utilisation du composant fait-form -->
                <!-- <?php if (isset($component)) { $__componentOriginal06e9a30a81dcff8e77910d8de2e92881 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06e9a30a81dcff8e77910d8de2e92881 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faits.fait-edit-form','data' => ['fait' => $fait]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('faits.fait-edit-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['fait' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fait)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06e9a30a81dcff8e77910d8de2e92881)): ?>
<?php $attributes = $__attributesOriginal06e9a30a81dcff8e77910d8de2e92881; ?>
<?php unset($__attributesOriginal06e9a30a81dcff8e77910d8de2e92881); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06e9a30a81dcff8e77910d8de2e92881)): ?>
<?php $component = $__componentOriginal06e9a30a81dcff8e77910d8de2e92881; ?>
<?php unset($__componentOriginal06e9a30a81dcff8e77910d8de2e92881); ?>
<?php endif; ?>-->
        </div>
    </section>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Laravel\chatterie\resources\views/faits/edit.blade.php ENDPATH**/ ?>