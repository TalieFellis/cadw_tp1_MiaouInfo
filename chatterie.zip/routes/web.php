<?php

use App\Http\Controllers\FaitController;
use Illuminate\Support\Facades\Route;

Route::get('/', [FaitController::class, 'index'])
        ->name('faits.index');

Route::get('/faits', [FaitController::class, 'list'])
        ->name('faits.list');

Route::get('/faits/create', [FaitController::class, 'create'])
        ->name('faits.create');

Route::post('/faits', [FaitController::class, 'store'])
        ->name('faits.store');

Route::delete('/faits/{id}', [FaitController::class, 'destroy'])
		->whereNumber('id')
        ->name('faits.destroy');

// Bonus 1 – Édition 
Route::get('/faits/{id}/edit', [FaitController::class, 'edit'])
        ->whereNumber('id')
        ->name('faits.edit');

Route::put('/faits/{id}', [FaitController::class, 'update'])
        ->whereNumber('id')
        ->name('faits.update');

